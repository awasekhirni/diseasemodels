import numpy as np 
from scipy.integrate import odeint 
import matplotlib.pyplot as plt 

#SEIR compartmental model 
#Susceptible, Expose, Infected, Recovered Population
# Assumption N = S+E+I+R 

#social distancing value range between 0 to 1
#0 - no social distancing 
# 0.1 - masks 10% of the population 
#0.2 - masks and hybrid 
#0.3
scd=0.3

#incubation time of the virus 
#5.1 days (average no of days)  for covid-19 
virus_incubationtime=5.1 #days
infective_time = 3.3  
#how infective the virus is 
R0=2.4 
#Population in the postcode 
N=40000

#initial number of infected and recovered individuals 
Exposed0=1/N 
Infected0=0.0 
Recovered0=0.0 
Susceptible0=1-Exposed0 -Infected0 -Recovered0 
#setting the initial conditions 
initialCondn=[Susceptible0,Exposed0,Infected0,Recovered0]

#computing contact rate, beta and mean recovery rate called gamma 
alpha = 1/virus_incubationtime
gamma = 1/infective_time
beta = R0*gamma 

def covidCompute(x,t):
    s,e,i,r = x 
    # derivative values 
    dx= np.zeros(4)
    dx[0] = -(1-scd)*beta * s * i
    dx[1] = (1-scd)*beta * s * i - alpha * e
    dx[2] = alpha * e - gamma * i
    dx[3] = gamma*i
    return dx 


#time linearly space over a span of 365 days 
t_interval= np.linspace(0,360,200)
x=odeint(covidCompute,initialCondn,t_interval)
s = x[:,0]; e = x[:,1]; i = x[:,2]; r = x[:,3]

#plot the data 
plt.figure(figsize=(10,5))

plt.subplot(2,1,1)
plt.title('Social Distancing = '+str(scd*100)+'%')
plt.plot(t_interval,s, color='blue', lw=3, label='Susceptible')
plt.plot(t_interval,r, color='red',  lw=3, label='Recovered')
plt.ylabel('Fraction')
plt.legend()

plt.subplot(2,1,2)
plt.plot(t_interval,i, color='orange', lw=3, label='Infective')
plt.plot(t_interval,e, color='purple', lw=3, label='Exposed')
plt.ylim(0, 0.2)
plt.xlabel('Time (days)')
plt.ylabel('Fraction')
plt.legend()

plt.show()